## Find Duplicate and Similar Images

Check out the tutorial
[Remove Duplicates and Find Similar Images with Python](https://medium.com/@somilshah112/how-to-find-duplicate-or-similar-images-quickly-with-python-2d636af9452f)

## Install Requirements

    pip install -r requirements.txt

## Usage

    python main.py

## Available Functions

- find_duplicates (Finding and Deleting Duplicates)
- find_similar (Finding Similar Images to a corresponding Image)
