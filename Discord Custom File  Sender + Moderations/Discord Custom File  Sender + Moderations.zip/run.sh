#! /bin/bash
nohup python3 Main.py &