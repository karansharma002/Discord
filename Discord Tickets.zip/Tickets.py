import discord
from discord.ext import commands
import json

bot = commands.Bot(command_prefix = '%',intents = discord.Intents.all())

@bot.event
async def on_ready():
    print('---------- SERVER HAS STARTED ---------')

@bot.command()
async def setupticket(ctx,channel:discord.TextChannel = None):
    if not channel:
        await ctx.send(':information_source: Usage: !setupticket `<#CHANNEL>` (USED TO FETCH THE CATEGORY)')
        return

    with open('Database.json') as f:
        data = json.load(f)
    
    category = str(channel.category.id)
    data[category] = {}

    def check(m):
        return m.author == ctx.author and m.channel.id == ctx.channel.id
    
    await ctx.send('1: Enter the Ticket Title')
    name = await bot.wait_for('message',check = check, timeout = 40)
    name = name.content

    await ctx.send('2: Enter the Ticket Description')
    description = await bot.wait_for('message',check = check, timeout = 40)
    description = description.content

    await ctx.send('3: Enter the Ticket Emoji')
    emoji = await bot.wait_for('message',check = check, timeout = 40)
    emoji = emoji.content

    data[category]['Name'] = name
    data[category]['Description'] = description
    data[category]['Emoji'] = emoji

    with open('Database.json','w') as f:
        json.dump(data,f,indent = 3)
    
    await ctx.send(':white_check_mark: Ticket Details added!')

@bot.command()
async def claim(ctx):
    with open('Tickets.json') as f:
        tickets = json.load(f)
    
    id = str(ctx.channel.id)

    if id in tickets:
        if tickets[id]['Owner'] == 'NONE':
            await ctx.send(':white_check_mark: You have claimed the TICKET.')
            tickets[id]['Owner'] = ctx.author.id
            with open('Tickets.json','w') as f: 
                json.dump(tickets,f,indent = 3)
            overwrites = {
                ctx.guild.default_role: discord.PermissionOverwrite(read_messages=False),
                ctx.guild.me: discord.PermissionOverwrite(read_messages=True,send_messages = True),
                ctx.author: discord.PermissionOverwrite(read_messages=True,send_messages = True)
            }
            await ctx.channel.edit(overwrites = overwrites)
        else:
            await ctx.send('This ticket is already claimed by someone else.')

    else:
        await ctx.send('Invalid Ticket Channel.')
    
    ctx.message.delete()

@bot.command()
async def loose(ctx):
    with open('Tickets.json') as f:
        tickets = json.load(f)
    
    id = str(ctx.channel.id)

    if id in tickets:
        if tickets[id]['Owner'] == ctx.author.id:
            await ctx.send(':white_check_mark: You have left the TICKET.')
            overwrites = {
                ctx.author: discord.PermissionOverwrite(read_messages=False,send_messages = False)
            }
            await ctx.channel.edit(overwrites = overwrites)
            tickets[id]['Owner'] = 'NONE'
            with open('Tickets.json','w') as f: 
                json.dump(tickets,f,indent = 3)

        else:
            await ctx.send('This ticket is not claimed by you.')

    else:
        await ctx.send('Invalid Ticket Channel.')
    
    ctx.message.delete()

@bot.command()
async def add(ctx,user:discord.Member = None):
    if not user:
        await ctx.send(':information_source: !add `<@user>`')
        return

    with open('Tickets.json') as f:
        tickets = json.load(f)
    
    id = str(ctx.channel.id)

    if id in tickets:
        if tickets[id]['Owner'] == ctx.author.id:
            await ctx.send(f':white_check_mark: You have added {user} in the Ticket.')
            overwrites = {
                user: discord.PermissionOverwrite(read_messages=True,send_messages = True)
            }
            await ctx.channel.edit(overwrites = overwrites)

        else:
            await ctx.send('This ticket is not claimed by you.')

    else:
        await ctx.send('Invalid Ticket Channel.')
    
    ctx.message.delete()

@bot.command()
async def remove(ctx,user:discord.Member = None):
    if not user:
        await ctx.send(':information_source: !remove `<@user>`')
        return

    with open('Tickets.json') as f:
        tickets = json.load(f)
    
    id = str(ctx.channel.id)

    if id in tickets:
        if tickets[id]['Owner'] == ctx.author.id:
            await ctx.send(f':white_check_mark: You have removed {user} from the Ticket.')
            overwrites = {
                user: discord.PermissionOverwrite(read_messages=False,send_messages = False)
            }
            await ctx.channel.edit(overwrites = overwrites)

        else:
            await ctx.send('This ticket is not claimed by you.')

    else:
        await ctx.send('Invalid Ticket Channel.')
    
    ctx.message.delete()

@bot.command()
async def post(ctx,channel:discord.TextChannel = None):
    with open('Database.json') as f:
        data = json.load(f)
    
    embed = discord.Embed(title = 'React below to open a Ticket',color = discord.Color.green())
    emojis = []
    for x in data:
        embed.add_field(name = data[x]['Name'],value = data[x]['Description'],inline = False)
        emojis.append(data[x]['Emoji'])
    
    msg = await ctx.send(embed = embed)
    for x in emojis:
        await msg.add_reaction(x)
    
@bot.event
async def on_raw_reaction_add(payload):
    channel = await bot.fetch_channel(payload.channel_id)
    guild = channel.guild
    member = channel.guild.get_member(int(payload.user_id))
    if member == bot.user:
        return

    emoji = payload.emoji
    emoji = str(emoji)
    with open('Tickets.json') as f:
        tickets = json.load(f)
    
    with open('Database.json') as f:
        database = json.load(f)
    
    id1 = str(channel.category.id)
    if id1 in database:
        if emoji == '🔒':
            if str(channel.id) in tickets:
                overwrites = {
                    guild.default_role: discord.PermissionOverwrite(read_messages=False),
                    guild.me: discord.PermissionOverwrite(read_messages=True,send_messages = True),
                    member: discord.PermissionOverwrite(read_messages=False,send_messages = False)
                }
                await channel.edit(overwrites=overwrites,name = f'Closed-{member.name}')        
                await channel.send(':lock: This Ticket has been CLOSED.')
                return

        if emoji == database[id1]['Emoji']:
            overwrites = {
                guild.default_role: discord.PermissionOverwrite(read_messages=False),
                guild.me: discord.PermissionOverwrite(read_messages=True,send_messages = True),
                member: discord.PermissionOverwrite(read_messages=True,send_messages = True)
            }
            category = discord.utils.get(guild.categories,id = int(id1))
            channel = await guild.create_text_channel(f'ticket-{member.name}', overwrites=overwrites,category = category)
            await channel.send(f'{member.mention} Welcome,')
            embed = discord.Embed(color = discord.Color.orange(),description = 'Our support team will be with you shortly.\nTo Close the ticket react with :lock:')
            embed.set_footer(text = bot.user.name)
            mg = await channel.send(embed = embed)
            await mg.add_reaction('🔒')
            tickets[str(channel.id)] = {}
            tickets[str(channel.id)]['Owner'] = 'NONE'
            with open('Tickets.json','w') as f:
                json.dump(tickets,f,indent = 3)
    
    else:
        if emoji == '🔒':
            if str(channel.id) in tickets:
                overwrites = {
                    guild.default_role: discord.PermissionOverwrite(read_messages=False),
                    guild.me: discord.PermissionOverwrite(read_messages=True,send_messages = True),
                    member: discord.PermissionOverwrite(read_messages=False,send_messages = False)
                }
                await channel.edit(overwrites=overwrites)        
                await channel.send(':lock: This Ticket has been CLOSED.')
            

bot.run('ODczMzMwOTQ4MjM2NzcxMzU4.YQ220w.4-qh5saWEOhPIET65kNmUbPwmZA')