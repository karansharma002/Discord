import discord
from discord.ext import commands,tasks
import json
import pandas as pd
from datetime import date
from datetime import timedelta
from datetime import datetime
from dateutil import parser

bot = commands.Bot(command_prefix= '!')

@bot.event
async def on_ready():
    print('---------- SERVER HAS STARTED ---------')
    await bot.wait_until_ready()
    trigger.start()

@tasks.loop(seconds = 45)

async def trigger():
    with open('Settings.json') as f:
        s = json.load(f)
    
    if not 'TIME' in s or not 'COMMAND' in s or not 'Channel' in s:
        return
    
    try:
        tm = s['TIME']
        t1 = parser.parse(str(tm))
        t2 = parser.parse(str(datetime.now()))
        t3 = t1 - t2
        t3 = round(t3.total_seconds())
        if t3 <= 0:
            cmd = s['COMMAND']
            channel = await bot.fetch_channel(s['Channel'])
            msg = await channel.send(cmd)
            await msg.delete()
            dt = datetime.strptime(tm, '%d/%m/%y %H:%M:%S')
            dt = dt + timedelta(days = 1)
            s['TIME'] = str(dt)
            with open('Settings.json','w') as f:
                json.dump(s,f,indent = 3)
    except:
        return
        

@bot.command()
async def setchannel(ctx,channel:discord.TextChannel = None):
    if not channel:
        await ctx.send(':information_source: Usage: !setchannel `<CHANNEL WHERE THE COMMAND IS EXECUTED>`')
        return


    with open('Settings.json', 'r') as f:
        settings = json.load(f)

    settings['Channel'] = channel.id

    with open('Settings.json','w') as f:
        json.dump(settings,f,indent = 3)
    
    await ctx.send(':white_check_mark: Channel has been set')  

@bot.command()
async def settime(ctx,*,var:str = None):
    if not var:
        await ctx.send(':information_source: Usage: !settime `<TIME TO EXECUTE AT PER DAY>` `(EXAMPLE: 04:10 HH:MM)`')
        return
    
    if var.count(':') > 1:
        await ctx.send(':warning: Invalid Format')
        return

    with open('Settings.json', 'r') as f:
        settings = json.load(f)
    
    dt = datetime.now()
    a = str(pd.to_datetime(str(dt)+' '+ str(var)))
    settings['TIME'] = var
    with open('Settings.json','w') as f:
        json.dump(settings,f,indent = 3)
    
    await ctx.send(':white_check_mark: Time has been set')  
    
@bot.command()
async def setcommand(ctx,*,var:str = None):
    if not var:
        await ctx.send(':information_source: Usage: !setcommand `<COMMAND NAME TO TRIGGER>`')
        return
    
    with open('Settings.json') as f:
        settings = json.load(f)
    
    settings['COMMAND'] = var

    with open('Settings.json','w') as f:
        json.dump(settings,f,indent = 3)
    
    await ctx.send(':white_check_mark: Command has been set')

TOKEN = 'YOUR TOKEN HERE'
bot.run(TOKEN)