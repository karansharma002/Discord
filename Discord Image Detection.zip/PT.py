import discord
from discord.ext import commands
import json

bot = commands.Bot(command_prefix = '!')

@bot.event
async def on_ready():
    print('------------ SERVER STARTED -----------------')

@bot.event
async def on_message(message):
    await bot.process_commands(message)
    author = str(message.author.id)
    channel = message.channel.id

    with open('DRT.json') as f:
        data = json.load(f)
    
    with open('SETG.json') as f:
        settings = json.load(f)
    
    if settings == {}:
        return

    if not author in data:
        data[author] = 0
    try:
        if channel == settings['1xChannel']:
            data[author] += 1
            with open('DRT.json','w') as f:
                json.dump(data, f,indent = 3)
        elif channel == settings['50xChannel']:
            data[author] += 50
            with open('DRT.json','w') as f:
                json.dump(data, f,indent = 3)

    except KeyError:
        pass

@bot.command()
async def set1xchannel(ctx,channel:discord.TextChannel = None):
    if not channel:
        await ctx.send(':information_source: Usage: !set1xchannel `<#CHANNEL>`')
        return

    with open('SETG.json') as f:
        settings = json.load(f)
    
    settings['1xChannel'] = channel.id

    with open('SETG.json','w') as f:
        json.dump(settings,f,indent = 3)
    
    await ctx.send(':white_check_mark: Channel Saved!!')

@bot.command()
async def set50xchannel(ctx,channel:discord.TextChannel = None):
    if not channel:
        await ctx.send(':information_source: Usage: !set50xchannel `<#CHANNEL>`')
        return

    
    with open('SETG.json') as f:
        settings = json.load(f)
    
    settings['50xChannel'] = channel.id

    with open('SETG.json','w') as f:
        json.dump(settings,f,indent = 3)
    
    await ctx.send(':white_check_mark: Channel Saved!!')

@bot.command()
async def leaderboard(ctx):
    with open('DRT.json','r') as f:
        data = json.load(f)
    
    with open('Warns.json') as f:
        warns = json.load(f)
    
    high_score = sorted(data,key = data.get,reverse = True)
    msg = ''
    for num,x in enumerate(high_score):
        user = await bot.fetch_user(int(x))
        if x in warns:
            msg += f"{num + 1}: {user} | **Warnings**: {warns[x]}\n"
        else:
            msg += f"{num + 1}: {user} | **Warnings**: {warns[x]}\n"

        if num == 15:
            break
        else:
            num += 1
    
    embed = discord.Embed(color = discord.Color.blurple(),description = msg)
    embed.set_author(name = f"Top {num} Users",icon = bot.user.avatar_url)
    await ctx.send(embed = embed)

@bot.command()
async def setpoints(ctx,user:discord.User = None,points:int = None):
    if not user or not points:
        await ctx.send(":information_source: Usage: !setpoints `<@user>` `<POINTS>`")
        return
    
    with open('DRT.json') as f:
        data = json.load(f)
    
    author = str(user.id)
    if not author in data:
        data[author] = 0
    data[author] += points
    with open('DRT.json','w') as f:
        json.dump(data, f, indent=3)
    
    await ctx.send(f':white_check_mark: Added {points} to {user}')

@bot.command()
async def removepoints(ctx,user:discord.User = None,points:int = None):
    if not user or not points:
        await ctx.send(":information_source: Usage: !removepoints `<@user>` `<POINTS>`")
        return
    
    with open('DRT.json') as f:
        data = json.load(f)
    
    author = str(user.id)
    if not author in data:
        data[author] = 0

    data[author] -= points if not data[author] - points < 0 else data[author]

    with open('DRT.json','w') as f:
        json.dump(data, f, indent=3)
    
    await ctx.send(f':white_check_mark: Added {points} to {user}')

@bot.command()
async def register(ctx,wallet:str = None):
    if not wallet:
        await ctx.send(':information_source: Usage: !register `<WALLET ADDRESS>`')
        return
    
    await ctx.send(':white_check_mark: Address Registered')

bot.run('ODgxNDMyOTI3ODA2ODQ0OTQ5.YSswYg.TzGJBa4qP9VMjgZf88O9fSrcIMw')