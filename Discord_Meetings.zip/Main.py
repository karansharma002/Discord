import discord
from discord.ext import commands, tasks
import json
from datetime import datetime

general_lock = 'False'
premium_lock = 'False'

lessons = {}
bot = commands.Bot(command_prefix = '*')

@bot.event
async def on_ready():
    print('------- MEETING BOT STARTED -----------')
    check_slots.start()

@bot.command()
async def livelesson(ctx, channel:discord.TextChannel = None):
    global lessons
    if not channel:
        await ctx.send(':information_source: Usage: *livelesson `<#CHANNEL>`')
        return

    role = discord.utils.get(ctx.guild.roles, name = 'Potential AWT')
    overwrites = {
        ctx.guild.default_role: discord.PermissionOverwrite(connect=False),
        role: discord.PermissionOverwrite(connect=True, speak = False),
        ctx.author: discord.PermissionOverwrite(speak=True)
    }

    category = discord.utils.get(ctx.guild.categories, id = 842175211185242173)
    vc = await ctx.guild.create_voice_channel("Live Lesson", overwrites=overwrites, category = category)
    await channel.send(f'A Lesson is now live in {vc.mention}, "Join NOW!!"\n{role.mention}')
    lessons['Live_Lesson'] = {}
    lessons['Live_Lesson']['Channel'] = channel.id
    lessons['Live_Lesson']['VC'] = vc.id
    return lessons

@bot.command()
async def endlivelesson(ctx):
    global lessons

    if 'Live_Lesson' in lessons:
        channel = await bot.fetch_channel(lessons['Live_Lesson']['Channel'])
        vc = await bot.fetch_channel(lessons['Live_Lesson']['VC'])

        await vc.delete()

        await channel.send('The live lesson has now ended. Thanks for joining!!')
        await ctx.send(':white_check_mark: Lessons Ended!!')
        lessons.pop('Live_Lesson')

    else:
        await ctx.send(':warning: No live lessons is active!!')

@bot.command()
async def plesson(ctx, channel:discord.TextChannel = None):
    global lessons
    if not channel:
        await ctx.send(':information_source: Usage: *plesson `<#CHANNEL>`')
        return

    role = discord.utils.get(ctx.guild.roles, name = 'Potential AWT')
    overwrites = {
        ctx.guild.default_role: discord.PermissionOverwrite(connect=False),
        ctx.author: discord.PermissionOverwrite(speak=True)
    }

    category = discord.utils.get(ctx.guild.categories, id = 897372481977978910)

    roles = ['AWT Student','OG AWT','AWT', 'Junior Whale']
    msg = ''
    for x in roles:
        temp_role = discord.utils.get(ctx.guild.roles, name = x)
        overwrites[temp_role] = discord.PermissionOverwrite(connect=True, speak = False)
        msg += f"{temp_role.mention} "

    vc = await ctx.guild.create_voice_channel("Premium Live Lesson", overwrites=overwrites, category = category)
    await channel.send(f'A Lesson is now live in {vc.mention}, "Join NOW!!\n{msg}"')
    lessons['P_Lesson'] = {}
    lessons['P_Lesson']['Channel'] = channel.id
    lessons['P_Lesson']['VC'] = vc.id
    return lessons

@bot.command()
async def endplesson(ctx):
    global lessons

    if 'P_Lesson' in lessons:
        channel = await bot.fetch_channel(lessons['P_Lesson']['Channel'])
        vc = await bot.fetch_channel(lessons['P_Lesson']['VC'])

        await vc.delete()

        await channel.send('The live lesson has now ended. Thanks for joining!!')
        await ctx.send(':white_check_mark: Lessons Ended!!')
        lessons.pop('P_Lesson')
        
    else:
        await ctx.send(':warning: No premium live lessons is active!!')
    
@bot.command()
async def setlessons(ctx,user:discord.User = None, amount:int = None):
    if not user or not amount:
        await ctx.send(':information_source: Usage: *setlessons `<@user>` `<amount>`')
        return
    
    with open('Users.json') as f:
        users = json.load(f)
    
    author = str(user.id)

    if not author in users:
        users[author] = {}
    
    users[author]['Quota'] = amount

    with open('Users.json','w') as f:
        json.dump(users,f,indent = 3)
    
    await ctx.send(':white_check_mark: Lessons Availablity amount updated!')

@bot.command()
async def lockdown(ctx):
    global premium_lock

    if premium_lock == 'False':
        channel = ctx.channel
        overwrites = {
            ctx.guild.default_role: discord.PermissionOverwrite(send_messages=False),
            ctx.guild.me: discord.PermissionOverwrite(send_messages=True),
            ctx.author: discord.PermissionOverwrite(send_messages= True)
        }

        for x in ['Catalyst Owner','Catalyst Admin','Catalyst Supporter','Catalyst Management']:
            role = discord.utils.get(ctx.guild.roles, name = x)
            overwrites[role] = discord.PermissionOverwrite(send_messages=True)
        
        await channel.edit(permissions = overwrites)

        await ctx.send(':white_check_mark: Channel Locked')

        premium_lock = 'True'

    else:
        channel = ctx.channel
        overwrites = {
            ctx.guild.default_role: discord.PermissionOverwrite(send_messages=True),
            ctx.guild.me: discord.PermissionOverwrite(send_messages=True),
            ctx.author: discord.PermissionOverwrite(send_messages= True)
        }

        await channel.edit(permissions = overwrites)

        await ctx.send(':white_check_mark: Channel Unlocked')
        premium_lock = 'False'

@bot.command()
async def lockgeneral(ctx):
    global general_lock

    if general_lock == 'False':
        channel = ctx.channel
        overwrites = {
            ctx.guild.default_role: discord.PermissionOverwrite(send_messages=False),
            ctx.guild.me: discord.PermissionOverwrite(send_messages=True),
            ctx.author: discord.PermissionOverwrite(send_messages= True)
        }

        for x in ['Catalyst Owner','Catalyst Admin','Catalyst Management']:
            role = discord.utils.get(ctx.guild.roles, name = x)
            overwrites[role] = discord.PermissionOverwrite(send_messages=True)
        
        await channel.edit(permissions = overwrites)

        await ctx.send(':white_check_mark: Channel Locked')
        general_lock = 'True'

    else:
        channel = ctx.channel
        overwrites = {
            ctx.guild.default_role: discord.PermissionOverwrite(send_messages=True),
            ctx.guild.me: discord.PermissionOverwrite(send_messages=True),
            ctx.author: discord.PermissionOverwrite(send_messages= True)
        }

        await channel.edit(permissions = overwrites)

        await ctx.send(':white_check_mark: Channel Unlocked')
        general_lock = 'False'
    
@bot.command()
async def slowdown(ctx, seconds: int =  None):
    if not seconds:
        await ctx.send(':information_source: Usage: *slowdown `<seconds [0 TO Disable]>`')
        return
    
    await ctx.channel.edit(slowmode_delay=seconds)

    await ctx.send(f':white_check_mark: Slowdown Enabled by: `{seconds}` SECONDS')

@bot.command()
async def post(ctx,channel:discord.TextChannel = None,*,text = None):
    if not channel or not text: 
        await ctx.send(':information_source:: Usage: *post `<#CHANNEL>` `<TEXT TO SEND>`')
        return
    
    embed = discord.Embed(color = discord.Color.green(), description = text)
    await channel.send(embed = embed)

@bot.command()
async def book(ctx,dt:str = None, tm:str = None):

    user = str(ctx.author.id)

    with open('Users.json') as f:
        users = json.load(f)

    with open('Slots.json') as f:
        slots = json.load(f)
    
    if not user in users:
        await ctx.send(':warning: No lesson slots are available. Please purchase lessons to continue.')
        return

    elif users[user]['Quota'] == 0:
        await ctx.send(':warning: You have exceeded the amount of lessons bookings. You have to purchase extra lessons to continue.')
        return

    if not dt or not tm or not lessons:
        await ctx.send(':information_source: Usage: *book `[DATE (DD/MM)]` `[TIME (HH:MM)]` `[AMOUNT OF LESSONS]`')
        return
    
    if not dt.count('/') == 1:
        await ctx.send(':warning: DATE format should be DD/MM')
        return

    if not tm.count(':') == 1:
        await ctx.send(':warning: TIME format should be HH:MM')
        return

    if dt in slots:
        if tm in slots[dt]:
            await ctx.send(':warning: The given time is not available for booking.')
            return
    
    if not dt in slots:
        slots[dt] = {}
        slots[dt]['Users'] = []
    
    if ctx.author.id in dt[users]:
        await ctx.send(':warning: You cannot book for the same day.')
        return

    slots[dt]['Users'].append(ctx.author.id)
    slots[dt][tm] = ctx.author.id

    with open('Slots.json','w') as f:
        json.dump(slots,f,indent = 3)
    
    users[user]['Quota'] -= 1

    with open('Users.json','w') as f:
        json.dump(users,f,indent = 3)

    await ctx.send(f':white_check_mark: You just booked a lesson. [You will be notified when time come]')

@tasks.loop()
async def check_slots():
    with open('Slots.json') as f:
        slots = json.load(f)
    
    a = datetime.now().strftime('%d/%m')
    b = datetime.now().strftime('%H:%M')

    for x in list(slots):
        if str(a.split('/')[0]) == str(x.split('/')[0]) and str(a.split('/')[1]) == str(x.split('/')[1]):
            for y in list(slots[x]):
                if str(b.split(':')[0]) == str(y.split(':')[0]) and str(b.split(':')[1]) == str(y.split(':')[1]):
                    owner = await bot.fetch_user(733015535515860992)
                    author = await bot.fetch_user(int(slots[x][y]))
                    guild = await bot.fetch_guild(842175209636888657)

                    overwrites = {
                        guild.default_role: discord.PermissionOverwrite(connect=False),
                        guild.me: discord.PermissionOverwrite(speak=True),
                        author: discord.PermissionOverwrite(speak= True)
                    }

                    channel = await guild.create_voice_channel(f"{author.name} - Lesson", overwrites=overwrites)
                    
                    msg = f'A Lesson is now live in {channel.mention}, "Join NOW!!"'
                    try:
                        await author.send(msg)
                        await owner.send(msg)
                    except:
                        continue

                    slots[x].pop(y)

                    with open('Slots.json','w') as f:
                        json.dump(slots, f , indent = 3)

           bot.run('ODk5NjIyMTU2NTI5NDM0NjY1.YW1cbA.q2H58VXzRuGGl6mS_DdQaSlPDaA')