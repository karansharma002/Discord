#! JAI BABA PAUNAHARI JI <3

import discord
from discord.ext import commands, tasks

import json


bot = commands.Bot(command_prefix = '!')

@bot.event
async def on_ready():
    print('------------- DISCORD BOT INSTANCE STARTED ---------------')

@bot.event
async def on_ready(message):
    #! VERIFY RULES AND SEND
    await bot.process_message(message)


#! RULE - UNIQUE NAME - CORROSPONDING CHANNEL - TEXT WITH A ROLE

@bot.command()
async def addrule(ctx,name:str = None,channel:discord.TextChannel = None):
    if not name or not channel:
        await ctx.send(':information_source: Usage: !addrule `<Rule Name>` `<#CHANNEL for which rule apply>`')
        return

    with open('Rules.json') as f:
        rules = json.load(f)

    id_ = str(channel.id)
    if not id_ in rules:
        await ctx.send(':warning: Channel not found. Please add it using !addchannel')
        return
    
    if name in rules[id_]:
        await ctx.send(':warning: Rule already exists. Please select a unique name')
        return
    
    rules[id_][name] = {}
    with open('Rules.json','w') as f:
        json.dump(rules,f,indent = 3)
    
    await ctx.send(':white_check_mark: Rule Added')

@bot.command()
async def addchannel(ctx,channel:discord.TextChannel = None):
    if not channel:
        await ctx.send(':information_source: Usage: !addchannel `<#CHANNEL>`')
        return
    
    with open('Rules.json') as f:
        rules = json.load(f)
    
    id_ = str(channel.id)
    if id_ in rules:
        await ctx.send(':warning: Channel already exists')
        return
    
    rules[id_] = {}
    with open('Rules.json','w') as f:
        json.dump(rules,f,indent = 3)
    
    await ctx.send(':white_check_mark: Channel Added')


@bot.command()
async def addtext(ctx,rule:str = None,*,text:str = None):
    if not rule or not text:
        return

